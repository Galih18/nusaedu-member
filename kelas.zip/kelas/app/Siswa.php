<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Siswa extends Model
{
    // Deklarasikan sebuah property bernama Table siswa bukan siswas (plural)
    protected $table = 'siswa';
    //Deklarasikan fillable Property di model
    protected $fillable = ['nama_depan','nama_belakang','jenis_kelamin','kontak','alamat','avatar','user_id'];

    public function getAvatar (){
        if (!$this->avatar){
            return asset('images/default.jpg');
        }
        return asset ('images/'.$this->avatar);
    }
}
