<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SiswaController extends Controller
{
    public function index(Request $request){
        // Untuk melakukan Pencarian dgn Query Builder
        if($request->has('cari')){
            $data_siswa = \App\Siswa::where('nama_depan','LIKE','%'.$request->cari.'%')->get();
        }
        else {
            $data_siswa = \App\Siswa::all();
            //sintaks diatas jika pencarian tdk ditemukan maka tampilkan data seluruhnya
        }
        //end pencarian
        return view('siswa.index',['data_siswa'=> $data_siswa]);
        
    }

    public function create(Request $request){
       
        //Insert ke Tabel Users
        $user = new \App\User;
        $user->role ='siswa';
        $user->name = $request->nama_depan;
        $user->email = $request->email;
        $user->password = bcrypt('rahasia'); //default rahasia nya adalah Rahasia bagi setiap yg login
        $user->remember_token = str_random(5);
        $user->save();

        //Insert ke Tabel Siswa
        $request->request->add(['user_id'=> $user->id]);
        $siswa = \App\Siswa::create($request->all());
        
        // Melakukan redirect halaman ke input data siswa & menampilkan flash message 'sukses' 'data berhasil diinput'
        return redirect('/siswa')->with('sukses','Data Berhasil di input');
    }

    public function edit($id){
        $siswa=\App\Siswa::find($id);
        return view('siswa/edit',['siswa'=>$siswa]);
    }

    public function update(Request $request, $id){
        //dd($request->all());
        $siswa=\App\Siswa::find($id);
        $siswa->update($request->all());
        if($request->hasFile('avatar')){
          $request->file('avatar')->move('images/',$request->file('avatar')->getClientOriginalName()); 
          //Script diatas berfungsi untuk memindahkan request file avatar kedalam folder images dan image disimpan dgn original name nya 
        
          $siswa->avatar = $request->file('avatar')->getClientOriginalName();
          $siswa->save();  
          //Script diatas untuk menyimpan avatar kedalam database
        }
        return redirect('/siswa')->with('update','Data Berhasil di Udpate');
    }

    public function delete($id){
        $siswa = \App\Siswa::find($id);
        $siswa->delete();
        return redirect('/siswa')->with('hapus','Data Berhasil Dihapus');
    }

    public function profile($id){
        $siswa = \App\Siswa::find($id);
        return view ('siswa.profile',['siswa' => $siswa]);
    }

}

