@extends('layouts.master')

@section('content')
    Dashboard
@stop