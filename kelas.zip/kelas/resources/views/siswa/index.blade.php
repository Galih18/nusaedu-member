<!-- Mengekstend layout master -->
@extends('layouts.master')

@section('content')
    <div class="main">
        <div class="main-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Data Siswa</h3>
                                        <div class="right">
                                         <button type="button" class="btn" data-toggle="modal" data-target="#exampleModal"><i class="lnr lnr-plus-circle"> Tambah Data Siswa</i></button>
                                        </div>
                                </div>
								<div class="panel-body">
									<table class="table table-hover">
										<thead>
											<tr>
                                            <th>Nama Depan</th>
                                            <th>Nama Belakang</th>
                                            <th>Jenis Kelamin</th>
                                            <th>kontak</th>
                                            <th>Alamat</th>
                                            <th>Opsi</th>
											</tr>
										</thead>
										<tbody>
                                            @foreach($data_siswa as $siswa)
                                            <tr>
                                                <td><a href="/siswa/{{$siswa->id}}/profile">{{$siswa->nama_depan}}</a></td>
                                                <td><a href="/siswa/{{$siswa->id}}/profile">{{$siswa->nama_belakang}}</a></td>
                                                <td>{{$siswa->jenis_kelamin}}</td>
                                                <td>{{$siswa->kontak}}</td>
                                                <td>{{$siswa->alamat}}</td>
                                                <td>
                                                    <a href="/siswa/{{$siswa->id}}/edit" class="btn btn-warning btn-sm">Edit</a>
                                                    
                                                    <a href="/siswa/{{$siswa->id}}/delete" class="btn btn-danger btn-sm" onclick="return confirm('Yakin Data Akan Dihapus')">Delete</a>
                                                </td>   
                                            </tr>
                                            @endforeach
										</tbody>
									</table>
								</div>
							
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Input Data Siswa</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <form action="/siswa/create" method="post"> <!-- method post dan diarahkan route ke URL:siswa/create -->
                   {{csrf_field()}} <!-- Security Form -->
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama Depan</label>
                            <input name="nama_depan" type="text" class="form-control" id="nama depan" aria-describedby="emailHelp" placeholder="Isikan Nama Depan">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama Belakang</label>
                            <input name="nama_belakang" type="text" class="form-control" id="nama belakang" aria-describedby="emailHelp" placeholder="Isikan Nama Belakang">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input name="email" type="email" class="form-control" id="nama belakang" aria-describedby="emailHelp" placeholder="Email">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlSelect1">Pilih Jenis Kelamin</label>
                            <select name="jenis_kelamin" class="form-control" id="jenkel">
                            <option value="L">Laki Laki</option>
                            <option value="P">Perempuan</option>
                            </select>
                        </div>        
                        <div class="form-group">
                            <label for="exampleInputEmail1">kontak</label>
                            <input name="kontak" type="text" class="form-control" id="kontak" aria-describedby="emailHelp" placeholder="Isikan kontak">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Alamat</label>
                            <textarea name="alamat" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                        </div> 
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-info">Submit</button>
                        </form>
                    </div>
                </div>
    </div>
@stop



