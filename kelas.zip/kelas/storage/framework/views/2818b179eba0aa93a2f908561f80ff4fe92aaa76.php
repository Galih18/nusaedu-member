<!-- Mengekstend layout master -->


<?php $__env->startSection('content'); ?>
    <div class="main">
        <div class="main-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Data Siswa</h3>
                                        <div class="right">
                                         <button type="button" class="btn" data-toggle="modal" data-target="#exampleModal"><i class="lnr lnr-plus-circle"> Tambah Data Siswa</i></button>
                                        </div>
                                </div>
								<div class="panel-body">
									<table class="table table-hover">
										<thead>
											<tr>
                                            <th>Nama Depan</th>
                                            <th>Nama Belakang</th>
                                            <th>Jenis Kelamin</th>
                                            <th>kontak</th>
                                            <th>Alamat</th>
                                            <th>Opsi</th>
											</tr>
										</thead>
										<tbody>
                                            <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><a href="/siswa/<?php echo e($siswa->id); ?>/profile"><?php echo e($siswa->nama_depan); ?></a></td>
                                                <td><a href="/siswa/<?php echo e($siswa->id); ?>/profile"><?php echo e($siswa->nama_belakang); ?></a></td>
                                                <td><?php echo e($siswa->jenis_kelamin); ?></td>
                                                <td><?php echo e($siswa->kontak); ?></td>
                                                <td><?php echo e($siswa->alamat); ?></td>
                                                <td>
                                                    <a href="/siswa/<?php echo e($siswa->id); ?>/edit" class="btn btn-warning btn-sm">Edit</a>
                                                    
                                                    <a href="/siswa/<?php echo e($siswa->id); ?>/delete" class="btn btn-danger btn-sm" onclick="return confirm('Yakin Data Akan Dihapus')">Delete</a>
                                                </td>   
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
								</div>
							
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Input Data Siswa</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <form action="/siswa/create" method="post"> <!-- method post dan diarahkan route ke URL:siswa/create -->
                   <?php echo e(csrf_field()); ?> <!-- Security Form -->
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama Depan</label>
                            <input name="nama_depan" type="text" class="form-control" id="nama depan" aria-describedby="emailHelp" placeholder="Isikan Nama Depan">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama Belakang</label>
                            <input name="nama_belakang" type="text" class="form-control" id="nama belakang" aria-describedby="emailHelp" placeholder="Isikan Nama Belakang">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input name="email" type="email" class="form-control" id="nama belakang" aria-describedby="emailHelp" placeholder="Email">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlSelect1">Pilih Jenis Kelamin</label>
                            <select name="jenis_kelamin" class="form-control" id="jenkel">
                            <option value="L">Laki Laki</option>
                            <option value="P">Perempuan</option>
                            </select>
                        </div>        
                        <div class="form-group">
                            <label for="exampleInputEmail1">kontak</label>
                            <input name="kontak" type="text" class="form-control" id="kontak" aria-describedby="emailHelp" placeholder="Isikan kontak">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Alamat</label>
                            <textarea name="alamat" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                        </div> 
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-info">Submit</button>
                        </form>
                    </div>
                </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/kelas/resources/views/siswa/index.blade.php ENDPATH**/ ?>